public class UseDivision {

    public static void main(String[] args) {

        InternationalDivision division1 =
                new InternationalDivision(
                        "Europe Sales",
                        1001,
                        "Germany",
                        "German");

        InternationalDivision division2 =
                new InternationalDivision(
                        "Asia Operations",
                        1002,
                        "Japan",
                        "Japanese");

        DomesticDivision division3 =
                new DomesticDivision(
                        "Southern Region",
                        2001,
                        "Texas");

        DomesticDivision division4 =
                new DomesticDivision(
                        "Eastern Region",
                        2002,
                        "Georgia");

        division1.display();
        division2.display();
        division3.display();
        division4.display();
    }
}
