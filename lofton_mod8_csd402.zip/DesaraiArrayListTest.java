import java.util.ArrayList;
import java.util.Scanner;

public class DesaraiArrayListTest {

    // Method to find the largest number
    public static Integer max(ArrayList<Integer> list) {

        if (list.isEmpty()) {
            return 0;
        }

        Integer largest = list.get(0);

        for (Integer number : list) {
            if (number > largest) {
                largest = number;
            }
        }

        return largest;
    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        ArrayList<Integer> numbers = new ArrayList<>();

        System.out.println("Enter integers (enter 0 to stop):");

        int value;

        do {
            value = input.nextInt();
            numbers.add(value);
        } while (value != 0);

        Integer largest = max(numbers);

        System.out.println("The largest value is: " + largest);

        input.close();
    }
}
