import java.util.ArrayList;
import java.util.Scanner;

public class DesaraiArrayListException {

    public static void main(String[] args) {

        ArrayList<String> colors = new ArrayList<>();

        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Yellow");
        colors.add("Black");
        colors.add("White");
        colors.add("Purple");
        colors.add("Orange");
        colors.add("Pink");
        colors.add("Gray");

        System.out.println("Colors in the ArrayList:");

        for (String color : colors) {
            System.out.println(color);
        }

        Scanner input = new Scanner(System.in);

        System.out.print("\nEnter a number (0-9) to see that color again: ");

        try {

            Integer index = Integer.valueOf(input.nextLine());

            System.out.println("Color: " + colors.get(index));

        } catch (IndexOutOfBoundsException e) {

            System.out.println("Exception thrown: Out of Bounds");

        } catch (NumberFormatException e) {

            System.out.println("Please enter a valid number.");

        }

        input.close();
    }
}
