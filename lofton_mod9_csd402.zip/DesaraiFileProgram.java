import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class DesaraiFileProgram {

    public static void main(String[] args) {

        try {

            File file = new File("data.file");

            FileWriter writer = new FileWriter(file, true);

            Random random = new Random();

            // Write 10 random numbers
            for (int i = 0; i < 10; i++) {
                writer.write(random.nextInt(100) + " ");
            }

            writer.write("\n");
            writer.close();

            // Read the file
            Scanner reader = new Scanner(file);

            System.out.println("Contents of data.file:");

            while (reader.hasNext()) {
                System.out.print(reader.next() + " ");
            }

            reader.close();

        } catch (IOException e) {
            System.out.println("An error occurred.");
        }

    }
}
